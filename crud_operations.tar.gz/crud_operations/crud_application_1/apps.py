from django.apps import AppConfig


class CrudApplication1Config(AppConfig):
    name = 'crud_application_1'
